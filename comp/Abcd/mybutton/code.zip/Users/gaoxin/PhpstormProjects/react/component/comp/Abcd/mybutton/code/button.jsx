import React,{Component} from "react";
import React,{Component} from "react-dom";
export default class Button extends Component{
    constructor(){
        super();
    }
    render(){
        return {
            <button>按钮</button>
        }
    }
}